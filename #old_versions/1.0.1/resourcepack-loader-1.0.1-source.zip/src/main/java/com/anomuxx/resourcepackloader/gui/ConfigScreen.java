package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.ResourcePackLoader;
import com.anomuxx.resourcepackloader.config.ModConfig;
import com.anomuxx.resourcepackloader.config.ServerProfile;
import com.anomuxx.resourcepackloader.manager.PackManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Configuration screen for managing server resource pack profiles.
 * Provides a GUI for adding/removing servers and configuring pack settings.
 */
public class ConfigScreen extends Screen {
    private final Screen parent;
    private final ModConfig config;
    
    // GUI components
    private ServerListWidget serverList;
    private PackListWidget packList;
    private TextFieldWidget serverAddressField;
    private ButtonWidget addServerButton;
    private ButtonWidget removeServerButton;
    private ButtonWidget saveButton;
    private ButtonWidget cancelButton;
    
    private String selectedServer = null;
    
    public ConfigScreen(Screen parent) {
        super(Text.literal("Resource Pack Loader Configuration"));
        this.parent = parent;
        this.config = ResourcePackLoader.getConfig();
    }
    
    @Override
    protected void init() {
        // Server address input field
        this.serverAddressField = new TextFieldWidget(
            this.textRenderer,
            this.width / 2 - 152,
            40,
            200,
            20,
            Text.literal("Server Address")
        );
        this.serverAddressField.setMaxLength(128);
        this.serverAddressField.setPlaceholder(Text.literal("Enter server address..."));
        this.addSelectableChild(this.serverAddressField);
        
        // Add server button
        this.addServerButton = ButtonWidget.builder(
            Text.literal("Add Server"),
            button -> addServer()
        ).dimensions(this.width / 2 + 55, 40, 100, 20).build();
        this.addDrawableChild(this.addServerButton);
        
        // Server list (left side)
        this.serverList = new ServerListWidget(
            this.client,
            150,
            this.height - 100,
            70,
            this.height - 30,
            25,
            this
        );
        this.addSelectableChild(this.serverList);
        
        // Update server list
        updateServerList();
        
        // Remove server button
        this.removeServerButton = ButtonWidget.builder(
            Text.literal("Remove"),
            button -> removeServer()
        ).dimensions(10, this.height - 25, 150, 20).build();
        this.addDrawableChild(this.removeServerButton);
        
        // Pack list (right side)
        this.packList = new PackListWidget(
            this.client,
            this.width - 170,
            this.height - 100,
            70,
            this.height - 30,
            25,
            this
        );
        this.addSelectableChild(this.packList);
        
        // Update pack list
        updatePackList();
        
        // Save button
        this.saveButton = ButtonWidget.builder(
            Text.literal("Save & Close"),
            button -> {
                ResourcePackLoader.saveConfig();
                this.close();
            }
        ).dimensions(this.width / 2 - 155, this.height - 25, 150, 20).build();
        this.addDrawableChild(this.saveButton);
        
        // Cancel button
        this.cancelButton = ButtonWidget.builder(
            Text.literal("Cancel"),
            button -> {
                ResourcePackLoader.reloadConfig();
                this.close();
            }
        ).dimensions(this.width / 2 + 5, this.height - 25, 150, 20).build();
        this.addDrawableChild(this.cancelButton);
    }
    
    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Render title
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 15, 0xFFFFFF);
        
        // Render section labels
        context.drawTextWithShadow(this.textRenderer, "Server Profiles:", 10, 70 - 12, 0xFFFFFF);
        context.drawTextWithShadow(this.textRenderer, "Resource Packs:", this.width - 160, 70 - 12, 0xFFFFFF);
        
        // Render selected server info
        if (selectedServer != null) {
            String info = "Selected: " + selectedServer;
            context.drawTextWithShadow(this.textRenderer, info, 170, 70 - 12, 0xAAAAAA);
        }
        
        // Render widgets
        super.render(context, mouseX, mouseY, delta);
    }
    
    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
    
    /**
     * Add a new server profile.
     */
    private void addServer() {
        String address = this.serverAddressField.getText().trim();
        
        if (address.isEmpty()) {
            return;
        }
        
        // Add server with empty profile
        ServerProfile profile = config.getServerProfile(address);
        if (profile == null) {
            profile = new ServerProfile();
            config.setServerProfile(address, profile);
        }
        
        // Clear input and update list
        this.serverAddressField.setText("");
        updateServerList();
        
        // Select the new server
        setSelectedServer(address);
    }
    
    /**
     * Remove the selected server profile.
     */
    private void removeServer() {
        if (selectedServer != null) {
            config.removeServerProfile(selectedServer);
            selectedServer = null;
            updateServerList();
            updatePackList();
        }
    }
    
    /**
     * Set the selected server and update pack list.
     */
    public void setSelectedServer(String server) {
        this.selectedServer = server;
        updatePackList();
    }
    
    /**
     * Get the currently selected server.
     */
    public String getSelectedServer() {
        return selectedServer;
    }
    
    /**
     * Update the server list widget.
     */
    private void updateServerList() {
        this.serverList.clear();
        
        // Add default profile entry
        this.serverList.addEntry(new ServerListWidget.ServerEntry("Default Profile", this.serverList));
        
        // Add all server profiles
        for (String server : config.getServers().keySet()) {
            this.serverList.addEntry(new ServerListWidget.ServerEntry(server, this.serverList));
        }
    }
    
    /**
     * Update the pack list widget based on selected server.
     */
    private void updatePackList() {
        this.packList.clear();
        
        if (selectedServer == null) {
            return;
        }
        
        // Get all available packs
        List<String> allPacks = PackManager.getAllAvailablePacks();
        
        // Get profile for selected server
        ServerProfile profile;
        if (selectedServer.equals("Default Profile")) {
            profile = config.getDefaultProfile();
        } else {
            profile = config.getServerProfile(selectedServer);
        }
        
        if (profile == null) {
            return;
        }
        
        // Add pack entries
        for (String packName : allPacks) {
            PackState state = PackState.NEUTRAL;
            
            if (profile.getEnable().contains(packName)) {
                state = PackState.ENABLE;
            } else if (profile.getDisable().contains(packName)) {
                state = PackState.DISABLE;
            }
            
            this.packList.addEntry(new PackListWidget.PackEntry(packName, state, this.packList));
        }
    }
    
    /**
     * Toggle the state of a pack for the selected server.
     */
    public void togglePack(String packName, PackState currentState) {
        if (selectedServer == null) {
            return;
        }
        
        ServerProfile profile;
        if (selectedServer.equals("Default Profile")) {
            profile = config.getDefaultProfile();
        } else {
            profile = config.getServerProfile(selectedServer);
        }
        
        if (profile == null) {
            return;
        }
        
        // Cycle through states: NEUTRAL -> ENABLE -> DISABLE -> NEUTRAL
        switch (currentState) {
            case NEUTRAL:
                profile.addEnablePack(packName);
                break;
            case ENABLE:
                profile.addDisablePack(packName);
                break;
            case DISABLE:
                profile.removePack(packName);
                break;
        }
        
        // Update pack list
        updatePackList();
    }
    
    /**
     * Enum for pack state in profile.
     */
    public enum PackState {
        NEUTRAL("○", 0xAAAAAA),    // Not configured
        ENABLE("✓", 0x55FF55),     // Enable on this server
        DISABLE("✗", 0xFF5555);    // Disable on this server
        
        public final String symbol;
        public final int color;
        
        PackState(String symbol, int color) {
            this.symbol = symbol;
            this.color = color;
        }
    }
}
