package com.anomuxx.resourcepackloader.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.widget.EntryListWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;

/**
 * Widget for displaying and selecting server profiles.
 */
public class ServerListWidget extends EntryListWidget<ServerListWidget.ServerEntry> {
    private final ConfigScreen parent;
    
    public ServerListWidget(MinecraftClient client, int width, int height, int top, int bottom, int itemHeight, ConfigScreen parent) {
        super(client, width, height, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.clearEntries();
    }
    
    public int addEntry(ServerEntry entry) {
        return super.addEntry(entry);
    }
    
    @Override
    public int getRowWidth() {
        return this.width - 10;
    }
    
    @Override
    protected int getScrollbarX() {
        return this.getX() + this.width - 6;
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        // Narration for accessibility
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubleClick) {
        if (click.button() == 0) {
            ServerEntry entry = this.getEntryAtPosition(click.x(), click.y());
            if (entry != null) {
                this.setSelected(entry);
                this.parent.setSelectedServer(entry.serverAddress);
                return true;
            }
        }

        return super.mouseClicked(click, doubleClick);
    }
    
    /**
     * Entry for a single server in the list.
     */
    public static class ServerEntry extends Entry<ServerEntry> {
        private final String serverAddress;
        private final ServerListWidget list;
        
        public ServerEntry(String serverAddress, ServerListWidget list) {
            this.serverAddress = serverAddress;
            this.list = list;
        }
        
        @Override
        public void render(DrawContext context, int mouseX, int mouseY, boolean hovered, float delta) {
            int x = this.getContentX();
            int y = this.getContentY();
            int entryWidth = this.getContentWidth();
            int entryHeight = this.getContentHeight();
            // Highlight if selected
            boolean selected = serverAddress.equals(list.parent.getSelectedServer());
            
            if (selected) {
                context.fill(x, y, x + entryWidth, y + entryHeight, 0x80FFFFFF);
            } else if (hovered) {
                context.fill(x, y, x + entryWidth, y + entryHeight, 0x40FFFFFF);
            }
            
            // Draw server name
            context.drawTextWithShadow(
                MinecraftClient.getInstance().textRenderer,
                serverAddress,
                x + 5,
                y + (entryHeight / 2) - 4,
                0xFFFFFF
            );
        }
    }
}
