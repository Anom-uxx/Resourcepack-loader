package com.anomuxx.resourcepackloader.manager;

import com.anomuxx.resourcepackloader.config.ServerProfile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3288;

/**
 * Manages resource pack enabling/disabling without triggering the full Mojang reload screen.
 * Uses internal F3+A style reload for seamless switching.
 */
public class PackManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("ResourcePackLoader");
    
    // Cooldown to prevent rapid reload loops (2 seconds)
    private static final long RELOAD_COOLDOWN_MS = 2000;
    private static long lastReloadTime = 0;
    
    /**
     * Apply a server profile by enabling/disabling the specified resource packs.
     * This method uses a lightweight reload mechanism similar to F3+A.
     * 
     * @param profile The server profile to apply
     * @return true if changes were made and reload was triggered
     */
    public static boolean applyProfile(ServerProfile profile) {
        if (profile == null || profile.isEmpty()) {
            LOGGER.debug("Profile is empty or null, skipping");
            return false;
        }
        
        // Check cooldown
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastReloadTime < RELOAD_COOLDOWN_MS) {
            LOGGER.warn("Reload cooldown active, skipping profile application");
            return false;
        }
        
        class_310 client = class_310.method_1551();
        if (client == null) {
            LOGGER.error("MinecraftClient is null");
            return false;
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            LOGGER.error("ResourcePackManager is null");
            return false;
        }
        
        // Get current enabled packs
        List<String> currentEnabled = new ArrayList<>(packManager.method_29210());
        List<String> newEnabled = new ArrayList<>(currentEnabled);
        
        boolean hasChanges = false;
        
        // Process packs to enable
        for (String packName : profile.getEnable()) {
            if (!currentEnabled.contains(packName)) {
                // Check if pack exists
                class_3288 packProfile = packManager.method_14449(packName);
                if (packProfile != null) {
                    if (!newEnabled.contains(packName)) {
                        newEnabled.add(packName);
                        hasChanges = true;
                        LOGGER.info("Enabling pack: {}", packName);
                    }
                } else {
                    LOGGER.warn("Pack not found: {}", packName);
                }
            }
        }
        
        // Process packs to disable
        for (String packName : profile.getDisable()) {
            if (currentEnabled.contains(packName)) {
                newEnabled.remove(packName);
                hasChanges = true;
                LOGGER.info("Disabling pack: {}", packName);
            }
        }
        
        // Apply changes if any
        if (hasChanges) {
            packManager.method_14447(newEnabled);
            
            // Trigger F3+A style reload (lightweight, in-game)
            triggerInGameReload(client);
            
            lastReloadTime = System.currentTimeMillis();
            LOGGER.info("Applied profile successfully");
            return true;
        } else {
            LOGGER.debug("No changes needed for this profile");
            return false;
        }
    }
    
    /**
     * Trigger an in-game resource reload (F3+A style).
     * This reloads resources without the red Mojang screen.
     */
    private static void triggerInGameReload(class_310 client) {
        LOGGER.info("Triggering in-game resource reload (F3+A style)");
        
        // Use the same reload method as F3+A
        // This creates a CompletableFuture that reloads resources
        CompletableFuture.runAsync(() -> {
            client.method_1521();
        }, client);
    }
    
    /**
     * Get all available resource packs.
     * 
     * @return List of all pack names
     */
    public static List<String> getAllAvailablePacks() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return new ArrayList<>();
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return new ArrayList<>();
        }
        
        List<String> packs = new ArrayList<>();
        for (class_3288 profile : packManager.method_14441()) {
            packs.add(profile.method_14463());
        }
        
        return packs;
    }
    
    /**
     * Get currently enabled resource packs.
     * 
     * @return List of enabled pack names
     */
    public static List<String> getEnabledPacks() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return new ArrayList<>();
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return new ArrayList<>();
        }
        
        return new ArrayList<>(packManager.method_29210());
    }
    
    /**
     * Check if a pack is currently enabled.
     */
    public static boolean isPackEnabled(String packName) {
        return getEnabledPacks().contains(packName);
    }
    
    /**
     * Get the display name for a resource pack.
     */
    public static String getPackDisplayName(String packName) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return packName;
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return packName;
        }
        
        class_3288 profile = packManager.method_14449(packName);
        if (profile != null) {
            return profile.method_14457().getString();
        }
        
        return packName;
    }
}
