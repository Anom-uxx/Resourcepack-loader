package com.anomuxx.resourcepackloader.gui;

import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * Widget for displaying and selecting server profiles.
 */
public class ServerListWidget extends class_350<ServerListWidget.ServerEntry> {
    private final ConfigScreen parent;
    
    public ServerListWidget(class_310 client, int width, int height, int top, int bottom, int itemHeight, ConfigScreen parent) {
        super(client, width, height, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.method_25339();
    }
    
    public int addEntry(ServerEntry entry) {
        return super.method_25321(entry);
    }
    
    @Override
    public int method_25322() {
        return this.field_22758 - 10;
    }
    
    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Narration for accessibility
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        if (!this.method_25405(click.comp_4798(), click.comp_4799())) {
            return super.method_25402(click, doubleClick);
        }

        if (click.method_74245() == 0) {
            ServerEntry entry = this.method_25308(click.comp_4798(), click.comp_4799());
            if (entry != null) {
                this.method_25313(entry);
                this.parent.setSelectedServer(entry.serverAddress);
                return true;
            }
        }

        return super.method_25402(click, doubleClick);
    }
    
    /**
     * Entry for a single server in the list.
     */
    public static class ServerEntry extends Entry<ServerEntry> {
        private final String serverAddress;
        private final ServerListWidget list;
        
        public ServerEntry(String serverAddress, ServerListWidget list) {
            this.serverAddress = serverAddress;
            this.list = list;
        }
        
        @Override
        public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
            int x = this.getContentX();
            int y = this.getContentY();
            int entryWidth = this.getContentWidth();
            int entryHeight = this.getContentHeight();
            // Highlight if selected
            boolean selected = serverAddress.equals(list.parent.getSelectedServer());
            
            if (selected) {
                context.method_25294(x, y, x + entryWidth, y + entryHeight, 0x80FFFFFF);
            } else if (hovered) {
                context.method_25294(x, y, x + entryWidth, y + entryHeight, 0x40FFFFFF);
            }
            
            // Draw server name
            context.method_25303(
                class_310.method_1551().field_1772,
                serverAddress,
                x + 5,
                y + (entryHeight / 2) - 4,
                0xFFFFFF
            );
        }
    }
}
