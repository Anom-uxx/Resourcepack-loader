package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.manager.PackManager;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * Widget for displaying and configuring resource pack states.
 */
public class PackListWidget extends class_350<PackListWidget.PackEntry> {
    private final ConfigScreen parent;
    
    public PackListWidget(class_310 client, int width, int height, int top, int bottom, int itemHeight, ConfigScreen parent) {
        super(client, width, height, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.method_25339();
    }
    
    public int addEntry(PackEntry entry) {
        return super.method_25321(entry);
    }
    
    @Override
    public int method_25322() {
        return this.field_22758 - 10;
    }
    
    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Narration for accessibility
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        if (!this.method_25405(click.comp_4798(), click.comp_4799())) {
            return super.method_25402(click, doubleClick);
        }

        if (click.method_74245() == 0) {
            PackEntry entry = this.method_25308(click.comp_4798(), click.comp_4799());
            if (entry != null) {
                this.method_25313(entry);
                this.parent.togglePack(entry.packName, entry.state);
                return true;
            }
        }

        return super.method_25402(click, doubleClick);
    }
    
    /**
     * Entry for a single resource pack in the list.
     */
    public static class PackEntry extends Entry<PackEntry> {
        private final String packName;
        private ConfigScreen.PackState state;
        private final boolean missing;
        private final PackListWidget list;
        
        public PackEntry(String packName, ConfigScreen.PackState state, boolean missing, PackListWidget list) {
            this.packName = packName;
            this.state = state;
            this.missing = missing;
            this.list = list;
        }
        
        @Override
        public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
            class_310 client = class_310.method_1551();
            
            // DEBUG: Test mit festen Koordinaten
            int index = list.method_25396().indexOf(this);
            if (index < 0) return;
            
            // Test: Render an fixer Position
            int testY = 100 + index * 25;
            int testX = 350;
            
            String displayName = PackManager.getPackDisplayName(packName);
            String label = state.symbol + " " + displayName.substring(0, Math.min(20, displayName.length()));
            
            // Grüner Hintergrund damit wir es sehen
            context.method_25294(testX, testY, testX + 200, testY + 20, 0xFF00FF00);
            
            context.method_25303(
                client.field_1772,
                label,
                testX + 5,
                testY + 5,
                0xFFFFFF
            );
        }
    }
}
