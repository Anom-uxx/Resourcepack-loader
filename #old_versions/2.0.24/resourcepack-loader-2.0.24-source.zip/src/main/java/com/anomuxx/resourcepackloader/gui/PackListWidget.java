package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.manager.PackManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.widget.EntryListWidget;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.text.Text;

/**
 * Widget for displaying and configuring resource pack states.
 */
public class PackListWidget extends EntryListWidget<PackListWidget.PackEntry> {
    private final ConfigScreen parent;
    
    public PackListWidget(MinecraftClient client, int width, int height, int top, int bottom, int itemHeight, ConfigScreen parent) {
        super(client, width, height, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.clearEntries();
    }
    
    public int addEntry(PackEntry entry) {
        return super.addEntry(entry);
    }
    
    @Override
    public int getRowWidth() {
        return this.width - 10;
    }
    
    @Override
    protected int getScrollbarX() {
        return this.getX() + this.width - 6;
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        // Narration for accessibility
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubleClick) {
        if (!this.isMouseOver(click.x(), click.y())) {
            return super.mouseClicked(click, doubleClick);
        }

        if (click.button() == 0) {
            PackEntry entry = this.getEntryAtPosition(click.x(), click.y());
            if (entry != null) {
                this.setSelected(entry);
                this.parent.togglePack(entry.packName, entry.state);
                return true;
            }
        }

        return super.mouseClicked(click, doubleClick);
    }
    
    /**
     * Entry for a single resource pack in the list.
     */
    public static class PackEntry extends Entry<PackEntry> {
        private final String packName;
        private ConfigScreen.PackState state;
        private final boolean missing;
        private final PackListWidget list;
        
        public PackEntry(String packName, ConfigScreen.PackState state, boolean missing, PackListWidget list) {
            this.packName = packName;
            this.state = state;
            this.missing = missing;
            this.list = list;
        }
        
        @Override
        public void render(DrawContext context, int mouseX, int mouseY, boolean hovered, float delta) {
            MinecraftClient client = MinecraftClient.getInstance();
            
            int index = list.children().indexOf(this);
            if (index < 0) return;
            
            // Verwende offizielle EntryListWidget Methoden
            int entryY = list.getRowTop(index);
            int entryX = list.getRowLeft();
            int entryWidth = list.getRowWidth();
            int entryBottom = list.getRowBottom(index);

            // Hintergrund bei Hover
            if (hovered) {
                context.fill(entryX, entryY, entryX + entryWidth, entryBottom, 0x40FFFFFF);
            }

            // Zeichne Status-Symbol
            context.drawTextWithShadow(
                client.textRenderer,
                state.symbol,
                entryX + 5,
                entryY + (list.itemHeight - 8) / 2,
                state.color
            );

            // Zeichne Pack-Name
            String displayName = PackManager.getPackDisplayName(packName);
            int nameColor = 0xFFFFFF;
            if (missing) {
                displayName = displayName + " (missing)";
                nameColor = 0xAAAAAA;
            }
            context.drawTextWithShadow(
                client.textRenderer,
                displayName,
                entryX + 20,
                entryY + (list.itemHeight - 8) / 2,
                nameColor
            );
        }
    }
}
