package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.manager.PackManager;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * Widget for displaying and configuring resource pack states.
 */
public class PackListWidget extends class_350<PackListWidget.PackEntry> {
    private final ConfigScreen parent;
    
    public PackListWidget(class_310 client, int width, int height, int top, int bottom, int itemHeight, ConfigScreen parent) {
        super(client, width, height, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.method_25339();
    }
    
    public int addEntry(PackEntry entry) {
        return super.method_25321(entry);
    }
    
    @Override
    public int method_25322() {
        return this.field_22758 - 10;
    }
    
    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Narration for accessibility
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        if (!this.method_25405(click.comp_4798(), click.comp_4799())) {
            return super.method_25402(click, doubleClick);
        }

        if (click.method_74245() == 0) {
            PackEntry entry = this.method_25308(click.comp_4798(), click.comp_4799());
            if (entry != null) {
                this.method_25313(entry);
                this.parent.togglePack(entry.packName, entry.state);
                return true;
            }
        }

        return super.method_25402(click, doubleClick);
    }
    
    /**
     * Entry for a single resource pack in the list.
     */
    public static class PackEntry extends Entry<PackEntry> {
        private final String packName;
        private ConfigScreen.PackState state;
        private final boolean missing;
        private final PackListWidget list;
        
        public PackEntry(String packName, ConfigScreen.PackState state, boolean missing, PackListWidget list) {
            this.packName = packName;
            this.state = state;
            this.missing = missing;
            this.list = list;
        }
        
        @Override
        public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
            class_310 client = class_310.method_1551();
            
            // Get position from the list - using available methods
            int index = list.method_25396().indexOf(this);
            int listTop = list.method_46427();
            int itemHeight = 25; // Same as passed to constructor
            int y = listTop + 4 + index * itemHeight;
            int x = list.method_46426() + 5;
            int entryWidth = list.method_25322();

            // Background
            if (hovered) {
                context.method_25294(x - 2, y - 2, x + entryWidth + 2, y + itemHeight - 2, 0x40FFFFFF);
            }

            // Draw state symbol
            context.method_25303(
                client.field_1772,
                state.symbol,
                x + 2,
                y + (itemHeight / 2) - 4,
                state.color
            );

            // Draw pack name (display name if available)
            String displayName = PackManager.getPackDisplayName(packName);
            int nameColor = 0xFFFFFF;
            if (missing) {
                displayName = displayName + " (missing)";
                nameColor = 0xAAAAAA;
            }
            context.method_25303(
                client.field_1772,
                displayName,
                x + 17,
                y + (itemHeight / 2) - 4,
                nameColor
            );
        }
    }
}
