package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.manager.PackManager;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * Widget for displaying and configuring resource pack states.
 */
public class PackListWidget extends class_350<PackListWidget.PackEntry> {
    private final ConfigScreen parent;
    
    public PackListWidget(class_310 client, int width, int bottom, int top, int itemHeight, ConfigScreen parent) {
        // Use constructor height parameter as bottom boundary for render area
        super(client, width, bottom, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.method_25339();
    }
    
    public int addEntry(PackEntry entry) {
        return super.method_25321(entry);
    }
    
    @Override
    public int method_25322() {
        return this.field_22758 - 10;
    }
    
    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Narration for accessibility
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        // Only handle clicks within the actual list boundaries
        if (!this.method_25405(click.comp_4798(), click.comp_4799())) {
            return false;
        }

        if (click.method_74245() == 0) {
            PackEntry entry = this.method_25308(click.comp_4798(), click.comp_4799());
            if (entry != null) {
                this.method_25313(entry);
                this.parent.togglePack(entry.packName, entry.state);
                return true;
            }
        }

        return super.method_25402(click, doubleClick);
    }
    
    /**
     * Entry for a single resource pack in the list.
     */
    public static class PackEntry extends Entry<PackEntry> {
        private final String packName;
        private ConfigScreen.PackState state;
        private final boolean missing;
        private final PackListWidget list;
        
        public PackEntry(String packName, ConfigScreen.PackState state, boolean missing, PackListWidget list) {
            this.packName = packName;
            this.state = state;
            this.missing = missing;
            this.list = list;
        }
        
        @Override
        public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
            class_310 client = class_310.method_1551();
            
            // Verwende die von EntryListWidget gesetzten Positionen
            int entryX = this.getContentX();
            int entryY = this.getContentY();
            int entryWidth = this.getContentWidth();
            int entryHeight = this.getContentHeight();

            // Hintergrund bei Hover
            if (hovered) {
                context.method_25294(entryX, entryY, entryX + entryWidth, entryY + entryHeight, 0x40FFFFFF);
            }

            // Zeichne Status-Symbol
            context.method_25303(
                client.field_1772,
                state.symbol,
                entryX + 5,
                entryY + (entryHeight - 8) / 2,
                state.color
            );

            // Zeichne Pack-Name
            String displayName = PackManager.getPackDisplayName(packName);
                int nameColor = 0xFFFFFFFF;
                if (missing) {
                    displayName = displayName + " (missing)";
                    nameColor = 0xFFAAAAAA;
                }
            context.method_25303(
                client.field_1772,
                displayName,
                entryX + 20,
                entryY + (entryHeight - 8) / 2,
                nameColor
            );
        }
    }
}
