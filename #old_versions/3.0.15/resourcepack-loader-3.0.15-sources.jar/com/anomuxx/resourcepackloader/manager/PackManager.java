package com.anomuxx.resourcepackloader.manager;

import com.anomuxx.resourcepackloader.config.ServerProfile;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3288;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manages resource pack enabling/disabling without triggering the full Mojang reload screen.
 * Uses internal F3+A style reload for seamless switching.
 */
public class PackManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("ResourcePackLoader");

    private static final Set<String> MISSING_PACK_WARNED = ConcurrentHashMap.newKeySet();
    
    // Cooldown to prevent rapid reload loops (2 seconds)
    private static final long RELOAD_COOLDOWN_MS = 2000;
    private static long lastReloadTime = 0;
    
    /**
     * Apply a server profile by enabling/disabling the specified resource packs.
     * This method uses a lightweight reload mechanism similar to F3+A.
     * 
     * @param profile The server profile to apply
     * @return true if changes were made and reload was triggered
     */
    public static boolean applyProfile(ServerProfile profile) {
        if (profile == null || profile.isEmpty()) {
            LOGGER.debug("Profile is empty or null, skipping");
            return false;
        }
        
        // Check cooldown
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastReloadTime < RELOAD_COOLDOWN_MS) {
            LOGGER.warn("Reload cooldown active, skipping profile application");
            return false;
        }
        
        class_310 client = class_310.method_1551();
        if (client == null) {
            LOGGER.error("MinecraftClient is null");
            return false;
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            LOGGER.error("ResourcePackManager is null");
            return false;
        }
        
        // Get current enabled packs
        List<String> currentEnabled = new ArrayList<>(packManager.method_29210());
        List<String> newEnabled = new ArrayList<>(currentEnabled);
        
        boolean hasChanges = false;
        
        // Process packs to enable
        for (String packName : profile.getEnable()) {
            if (!currentEnabled.contains(packName)) {
                // Check if pack exists
                class_3288 packProfile = packManager.method_14449(packName);
                if (packProfile != null) {
                    if (!newEnabled.contains(packName)) {
                        newEnabled.add(packName);
                        hasChanges = true;
                        LOGGER.info("Enabling pack: {}", packName);
                    }
                } else {
                    if (MISSING_PACK_WARNED.add(packName)) {
                        LOGGER.warn("Pack not found: {}", packName);
                    } else {
                        LOGGER.debug("Pack still not found: {}", packName);
                    }
                }
            }
        }
        
        // Process packs to disable
        for (String packName : profile.getDisable()) {
            if (currentEnabled.contains(packName)) {
                newEnabled.remove(packName);
                hasChanges = true;
                LOGGER.info("Disabling pack: {}", packName);
            }
        }
        
        // Apply changes if any
        if (hasChanges) {
            packManager.method_14447(newEnabled);
            
            // Trigger F3+A style reload (lightweight, in-game)
            triggerInGameReload(client);
            
            lastReloadTime = System.currentTimeMillis();
            LOGGER.info("Applied profile successfully");
            return true;
        } else {
            LOGGER.debug("No changes needed for this profile");
            return false;
        }
    }
    
    /**
     * Trigger an in-game resource reload (F3+A style).
     * This reloads resources without the red Mojang screen.
     */
    private static void triggerInGameReload(class_310 client) {
        LOGGER.info("Triggering in-game resource reload (F3+A style)");
        
        // Use the same reload method as F3+A
        // This creates a CompletableFuture that reloads resources
        CompletableFuture.runAsync(() -> {
            client.method_1521();
        }, client);
    }
    
    /**
     * Get all available resource packs.
     * 
     * @return List of all pack names
     */
    public static List<String> getAllAvailablePacks() {
        return getAllAvailablePacks(false);
    }

    /**
     * Get available resource packs with optional filtering to show only packs that come from the user's resourcepacks folder
     * (folders or zip files). This avoids showing mod-provided built-ins when the filter is enabled.
     */
    public static List<String> getAllAvailablePacks(boolean resourcePacksOnly) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return new ArrayList<>();
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return new ArrayList<>();
        }
        
        Set<String> localPackIds = resourcePacksOnly ? getLocalResourcePackIds() : Set.of();
        // Whitelist vanilla packs so the filter still shows them
        Set<String> vanillaIds = Set.of("vanilla", "programmer_art", "high_contrast");

        List<String> packs = new ArrayList<>();
        for (class_3288 profile : packManager.method_14441()) {
            String id = profile.method_14463();
            String idLower = id.toLowerCase();

            if (resourcePacksOnly) {
                String tail = id.contains("/") ? id.substring(id.lastIndexOf('/') + 1) : id;
                String tailLower = tail.toLowerCase();
                boolean matchesLocal = localPackIds.contains(idLower) || localPackIds.contains(tailLower);
                boolean isVanilla = vanillaIds.contains(idLower);

                // In filtered mode, only show vanilla packs or those backed by files/folders in resourcepacks/
                if (!matchesLocal && !isVanilla) {
                    continue;
                }
            }

            packs.add(id);
        }

        return packs;
    }

    /**
     * Collect ids that correspond to items in the resourcepacks/ folder (zip or directory). The id is assumed to be
     * the base file/folder name without the .zip extension.
     */
    private static Set<String> getLocalResourcePackIds() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return Set.of();
        }

        Path dir = FabricLoader.getInstance().getGameDir().resolve("resourcepacks");
        if (!Files.isDirectory(dir)) {
            return Set.of();
        }

        Set<String> ids = new HashSet<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path p : stream) {
                String name = p.getFileName().toString();
                if (name.toLowerCase().endsWith(".zip")) {
                    name = name.substring(0, name.length() - 4);
                }
                ids.add(name.toLowerCase());
            }
        } catch (Exception ignored) {
        }
        return ids;
    }
    
    /**
     * Get currently enabled resource packs.
     * 
     * @return List of enabled pack names
     */
    public static List<String> getEnabledPacks() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return new ArrayList<>();
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return new ArrayList<>();
        }
        
        return new ArrayList<>(packManager.method_29210());
    }
    
    /**
     * Check if a pack is currently enabled.
     */
    public static boolean isPackEnabled(String packName) {
        return getEnabledPacks().contains(packName);
    }
    
    /**
     * Get the display name for a resource pack.
     */
    public static String getPackDisplayName(String packName) {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return packName;
        }
        
        class_3283 packManager = client.method_1520();
        if (packManager == null) {
            return packName;
        }
        
        class_3288 profile = packManager.method_14449(packName);
        if (profile != null) {
            return profile.method_14457().getString();
        }
        
        return packName;
    }
}
