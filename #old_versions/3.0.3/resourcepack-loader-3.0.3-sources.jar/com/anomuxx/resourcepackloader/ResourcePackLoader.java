package com.anomuxx.resourcepackloader;

import com.anomuxx.resourcepackloader.config.ModConfig;
import com.anomuxx.resourcepackloader.event.ServerConnectionHandler;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Main entry point for the Resource Pack Loader mod.
 * This is a CLIENT-SIDE ONLY mod for managing resource packs based on server connections.
 */
public class ResourcePackLoader implements ClientModInitializer {
    public static final String MOD_ID = "resourcepack-loader";
    public static final Logger LOGGER = LoggerFactory.getLogger("ResourcePackLoader");
    
    private static ModConfig config;
    private static class_304 configKeyBinding;
    
    @Override
    public void onInitializeClient() {
        LOGGER.info("Initializing Resource Pack Loader");
        
        // Load configuration
        config = ModConfig.load();
        
        // Initialize event handlers
        ServerConnectionHandler.init(config);
        
        // Register keybinding for config screen (Right Shift)
        configKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.resourcepack-loader.config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            class_304.class_11900.field_62556
        ));
        
        // Register tick event to check for keybinding
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKeyBinding.method_1436()) {
                openConfigScreen(client);
            }
        });
        
        LOGGER.info("Resource Pack Loader initialized successfully");
    }
    
    /**
     * Get the current configuration instance.
     */
    public static ModConfig getConfig() {
        return config;
    }
    
    /**
     * Save the configuration to disk.
     */
    public static void saveConfig() {
        if (config != null) {
            config.save();
        }
    }
    
    /**
     * Reload the configuration from disk.
     */
    public static void reloadConfig() {
        config = ModConfig.load();
        ServerConnectionHandler.reloadConfig(config);
        LOGGER.info("Configuration reloaded");
    }
    
    /**
     * Open the configuration screen.
     */
    public static void openConfigScreen(class_310 client) {
        if (client != null) {
            // Import is done in the GUI class to avoid circular dependencies
            client.execute(() -> {
                try {
                    Class<?> screenClass = Class.forName("com.anomuxx.resourcepackloader.gui.ConfigScreen");
                    Object screen = screenClass.getDeclaredConstructor(net.minecraft.class_437.class)
                        .newInstance(client.field_1755);
                    client.method_1507((net.minecraft.class_437) screen);
                } catch (Exception e) {
                    LOGGER.error("Failed to open config screen", e);
                }
            });
        }
    }
}
