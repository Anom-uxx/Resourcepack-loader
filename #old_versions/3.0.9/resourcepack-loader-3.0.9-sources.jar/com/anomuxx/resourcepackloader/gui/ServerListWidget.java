package com.anomuxx.resourcepackloader.gui;

import com.anomuxx.resourcepackloader.ResourcePackLoader;
import com.anomuxx.resourcepackloader.config.ServerProfile;
import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_11909;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_350;
import net.minecraft.class_6382;

/**
 * Widget for displaying and selecting server profiles.
 */
public class ServerListWidget extends class_350<ServerListWidget.ServerEntry> {
    private final ConfigScreen parent;

    private static final Map<String, String> FAVICON_BY_ADDRESS = new ConcurrentHashMap<>();
    private static final Map<String, class_2960> ICON_ID_BY_ADDRESS = new ConcurrentHashMap<>();
    
    public ServerListWidget(class_310 client, int width, int bottom, int top, int itemHeight, ConfigScreen parent) {
        // Use constructor height parameter as bottom boundary for render area
        super(client, width, bottom, top, itemHeight);
        this.parent = parent;
    }
    
    public void clear() {
        this.method_25339();
    }
    
    public int addEntry(ServerEntry entry) {
        return super.method_25321(entry);
    }
    
    @Override
    public int method_25322() {
        return this.field_22758 - 10;
    }
    
    @Override
    protected int method_65507() {
        return this.method_46426() + this.field_22758 - 6;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        // Narration for accessibility
    }

    @Override
    public boolean method_25402(class_11909 click, boolean doubleClick) {
        // Only handle clicks within the actual list boundaries
        if (!this.method_25405(click.comp_4798(), click.comp_4799())) {
            return false;
        }

        if (click.method_74245() == 0) {
            ServerEntry entry = this.method_25308(click.comp_4798(), click.comp_4799());
            if (entry != null) {
                this.method_25313(entry);
                this.parent.setSelectedServer(entry.serverAddress);
                return true;
            }
        }

        return super.method_25402(click, doubleClick);
    }
    
    /**
     * Entry for a single server in the list.
     */
    public static class ServerEntry extends Entry<ServerEntry> {
        private final String serverAddress;
        private final ServerListWidget list;
        
        public ServerEntry(String serverAddress, ServerListWidget list) {
            this.serverAddress = serverAddress;
            this.list = list;
        }

        public String getServerAddress() {
            return this.serverAddress;
        }
        
        @Override
        public void render(class_332 context, int mouseX, int mouseY, boolean hovered, float delta) {
            // Verwende die von EntryListWidget gesetzten Positionen
            int entryX = this.getContentX();
            int entryY = this.getContentY();
            int entryWidth = this.getContentWidth();
            int entryHeight = this.getContentHeight();
            
            System.out.println("ServerEntry.render(): " + serverAddress + " at X=" + entryX + " Y=" + entryY + " W=" + entryWidth + " H=" + entryHeight);
            
            // Prüfe ob dieser Eintrag ausgewählt ist
            boolean selected = serverAddress.equals(list.parent.getSelectedServer());
            
            // Hintergrund
            if (selected) {
                context.method_25294(entryX, entryY, entryX + entryWidth, entryY + entryHeight, 0x80FFFFFF);
            } else if (hovered) {
                context.method_25294(entryX, entryY, entryX + entryWidth, entryY + entryHeight, 0x40FFFFFF);
            }
            
            // Server Name mit Pack-Anzahl
            String label = serverAddress;
            ServerProfile profile = list.parent.getProfileForServerEntry(serverAddress);
            if (profile != null && !profile.isEmpty()) {
                int enableCount = profile.getEnable().size();
                int disableCount = profile.getDisable().size();
                label = label + " (" + enableCount + "/" + disableCount + ")";
            }
            
            // Schriftfarbe: Hellrot (ausgewählt) oder Weiß (normal)
            int textColor = selected ? 0xFFFF5555 : 0xFFFFFFFF;
            
            context.method_25303(
                class_310.method_1551().field_1772,
                label,
                entryX + 5,
                entryY + (entryHeight - 8) / 2,
                textColor
            );
        }

        private static class_2960 getOrCreateIconId(String address) {
            if (address == null || address.equals("Default Profile")) {
                return null;
            }

            class_310 client = class_310.method_1551();
            if (client == null) {
                return null;
            }

            // Try to fetch favicon from Minecraft's saved server list.
            String favicon = tryResolveFavicon(address);
            if (favicon == null || favicon.isBlank()) {
                return null;
            }

            String previous = FAVICON_BY_ADDRESS.get(address);
            if (favicon.equals(previous)) {
                return ICON_ID_BY_ADDRESS.get(address);
            }

            class_2960 id = class_2960.method_60655("resourcepack-loader", "server_icon/" + Integer.toHexString(address.hashCode()));
            class_1043 texture = decodeFaviconTexture(favicon);
            if (texture == null) {
                return null;
            }

            try {
                client.method_1531().method_4616(id, texture);
                FAVICON_BY_ADDRESS.put(address, favicon);
                ICON_ID_BY_ADDRESS.put(address, id);
                return id;
            } catch (Throwable t) {
                return null;
            }
        }

        private static String tryResolveFavicon(String address) {
            // Best-effort reflection against ServerList APIs across 1.21.x.
            try {
                class_310 client = class_310.method_1551();
                if (client == null) {
                    return null;
                }

                Object serverList = client.getClass().getMethod("getServerList").invoke(client);
                if (serverList == null) {
                    return null;
                }

                // ensure loaded
                try {
                    serverList.getClass().getMethod("loadFile").invoke(serverList);
                } catch (Throwable ignored) {
                }

                int size;
                try {
                    size = (int) serverList.getClass().getMethod("size").invoke(serverList);
                } catch (Throwable t) {
                    return null;
                }

                for (int i = 0; i < size; i++) {
                    Object info;
                    try {
                        info = serverList.getClass().getMethod("get", int.class).invoke(serverList, i);
                    } catch (Throwable t) {
                        try {
                            info = serverList.getClass().getMethod("getServerInfo", int.class).invoke(serverList, i);
                        } catch (Throwable t2) {
                            continue;
                        }
                    }
                    if (info == null) {
                        continue;
                    }

                    String addr;
                    try {
                        addr = (String) info.getClass().getField("address").get(info);
                    } catch (Throwable t) {
                        continue;
                    }

                    if (addr == null || !addr.equalsIgnoreCase(address)) {
                        continue;
                    }

                    // favicon string field/method differs across versions; try common names
                    try {
                        Object v = info.getClass().getMethod("getFavicon").invoke(info);
                        if (v instanceof String s) {
                            return s;
                        }
                    } catch (Throwable ignored) {
                    }
                    try {
                        Object v = info.getClass().getField("favicon").get(info);
                        if (v instanceof String s) {
                            return s;
                        }
                    } catch (Throwable ignored) {
                    }
                }
            } catch (Throwable ignored) {
            }

            return null;
        }

        private static class_1043 decodeFaviconTexture(String favicon) {
            try {
                String base64 = favicon;
                String prefix = "data:image/png;base64,";
                if (base64.startsWith(prefix)) {
                    base64 = base64.substring(prefix.length());
                }

                byte[] bytes = Base64.getDecoder().decode(base64);
                class_1011 image = class_1011.method_4309(new ByteArrayInputStream(bytes));
                Supplier<String> nameSupplier = () -> "resourcepack-loader/server_icon";
                return new class_1043(nameSupplier, image);
            } catch (Throwable t) {
                return null;
            }
        }
    }
}
